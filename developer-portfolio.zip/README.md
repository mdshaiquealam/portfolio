# Md Shaique Alam — Modern Developer Portfolio

A developer portfolio website crafted for **Md Shaique Alam**, Computer Science Engineering student and aspiring **Java Full Stack Developer**.

Built with **React**, **Vite**, **Tailwind CSS**, and **Framer Motion**, featuring a dark aesthetic with purple/blue glowing accents, interactive Java code simulator, glassmorphism cards, animated skill proficiencies, and project architecture details.

---

## 🚀 Key Features

- **Theme Switching**: Smooth dark/light mode toggle with state persistence in `localStorage`.
- **Hero Section**:
  - Animated introduction with glowing `"Open to Internship Opportunities"` status badge.
  - Interactive **Java Code Sandbox** (`Developer.java`) with syntax highlighting, live run compilation animation, and code copy.
  - Direct CTAs: *View My Projects*, *Download Resume*, and *Contact Me*.
- **About Me**: Narrative of academic background in Computer Science, commitment to Java Full Stack development, and 4 core engineering pillars.
- **Skills Matrix**:
  - Grouped into **Programming**, **Frontend**, **Database**, **Core Concepts (OOP, DSA, OS, CN, DBMS)**, and **Tools**.
  - Interactive category filter tabs, live search input, and animated proficiency bars.
- **Academic & Practical Projects**:
  - **Doctor Appointment Management System** (Java, Spring Boot, MySQL, RBAC, REST APIs)
  - **Secure Dashboard UI** (React, JavaScript, HTML, CSS)
  - **Bank Management System** (Java, OOP, Banking Logic)
  - **Personal Portfolio Website** (React, Tailwind CSS, Framer Motion)
  - Interactive **Architecture & Details Modal** revealing OOP design patterns and feature breakdowns.
- **Education Timeline**: B.Tech CSE timeline with coursework badges and placeholders for university, graduation year, and CGPA.
- **Experience & Certifications**:
  - Tabbed interface with clear, editable placeholders for internships and technical certificates.
- **Coding Profiles**:
  - Cards for GitHub, LinkedIn, LeetCode, GeeksforGeeks, and HackerRank with one-click URL copy and external links.
- **Verified Contact Form**:
  - Comprehensive client-side form validation (name, email format, subject, message).
  - Direct mail client trigger (`mailto:`) with pre-filled inputs and confetti celebration.
  - Direct email address copy button with visual checkmark feedback.
- **Interactive Resume Modal**:
  - Clean resume preview with print/save as PDF support (`window.print()`).
- **Custom Cursor**:
  - Ambient trailing pointer with interactive hover rings (auto-disabled on touch devices for maximum usability).

---

## 🛠️ Tech Stack

- **Framework**: [React 19](https://react.dev/) + [Vite 8](https://vite.dev/)
- **Styling**: [Tailwind CSS 3.4](https://tailwindcss.com/)
- **Animations**: [Framer Motion](https://www.framer.com/motion/)
- **Icons**: [Lucide React](https://lucide.dev/) + Pixel-perfect custom brand SVGs
- **Celebration Effects**: [Canvas Confetti](https://www.npmjs.com/package/canvas-confetti)

---

## 📁 Project Structure

```text
developer-portfolio/
├── public/
│   └── _redirects              # Netlify client-side routing
├── src/
│   ├── components/
│   │   ├── About.jsx           # Engineering journey & core pillars
│   │   ├── CodingProfiles.jsx  # GitHub, LinkedIn, LeetCode, GFG, HackerRank
│   │   ├── Contact.jsx         # Form with validation & mailto submission
│   │   ├── CustomCursor.jsx    # Fluid cursor with touch detection
│   │   ├── Education.jsx       # B.Tech timeline & coursework
│   │   ├── ExperienceCertifications.jsx # Editable placeholders
│   │   ├── Footer.jsx          # Quick links & back-to-top
│   │   ├── Hero.jsx            # Headline & interactive Java code preview
│   │   ├── Icons.jsx           # Clean SVG brand icons
│   │   ├── Navbar.jsx          # Glassmorphism header & theme toggle
│   │   ├── NotFound.jsx        # Custom 404 page
│   │   ├── Projects.jsx        # Project cards & architectural modal
│   │   ├── ResumeModal.jsx     # Printable resume preview
│   │   └── Skills.jsx          # Categorized skills & search
│   ├── data/
│   │   └── portfolioData.js    # Centralized configuration file (EDIT HERE!)
│   ├── App.jsx                 # Main application component
│   ├── index.css               # Tailwind directives & glassmorphism utilities
│   └── main.jsx                # React root mount
├── index.html                  # SEO meta tags, Google Fonts (Inter & JetBrains Mono)
├── package.json
├── tailwind.config.js          # Custom theme colors, gradients & glow effects
└── vercel.json                 # Vercel SPA routing
```

---

## ✏️ How to Personalize Your Data

All portfolio data is separated cleanly from UI components in **`src/data/portfolioData.js`**.

1. **Update Personal Information**:
   Open `src/data/portfolioData.js` and modify `personalInfo`:
   - Name, role, email, headline, bio, and social links.

2. **Add Your College & CGPA**:
   Edit `educationData` to replace `[Enter Your College / University Name]`, graduation year, and CGPA.

3. **Add Your Internship & Training**:
   Edit `experienceData.internships` with your actual company name, duration, and project contributions.

4. **Add Your Certifications**:
   Edit `experienceData.certifications` with your certificate names, issuing organizations, and credential URLs.

5. **Link Your Repositories**:
   In `projectsData`, update the `github` and `liveDemo` URLs with your real links.

---

## 💻 Getting Started Locally

### Prerequisites
- **Node.js** (v18 or higher recommended; tested on Node v24)
- **npm** or **pnpm** / **yarn**

### 1. Install Dependencies
```bash
npm install
```

### 2. Start the Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:5173`.

### 3. Production Build & Test
```bash
npm run build
npm run preview
```

---

## 🌐 Deployment Instructions

### Deploy to Vercel
1. Push your repository to GitHub (`https://github.com/mdshaiquealam/developer-portfolio`).
2. Log into [Vercel](https://vercel.com/) and click **"Add New Project"**.
3. Import your GitHub repository.
4. Framework preset will automatically be detected as **Vite**.
5. Click **"Deploy"**. The included `vercel.json` ensures all routes resolve to `index.html`.

### Deploy to Netlify
1. Log into [Netlify](https://www.netlify.com/).
2. Select **"Add new site"** &rarr; **"Import an existing project"** &rarr; **GitHub**.
3. Set build settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
4. Click **"Deploy site"**. The included `public/_redirects` ensures seamless SPA routing.
