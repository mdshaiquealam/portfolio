/**
 * Portfolio Configuration Data
 * Md Shaique Alam - Java Full Stack Developer & Aspiring Software Engineer
 * Government Engineering College Samastipur (2022 - 2026)
 */

export const personalInfo = {
  name: "Md Shaique Alam",
  firstName: "Shaique",
  role: "Java Full Stack Developer",
  subRole: "Cyber Security & Software Engineering",
  education: "B.Tech in Computer Science and Engineering",
  specialization: "Cyber Security",
  college: "Government Engineering College Samastipur",
  graduationYear: "2026",
  batch: "2022 – 2026",
  phone: "+91-7654988688",
  headline: "Building Secure, Scalable Applications with Java, Spring Boot & Modern Web Technologies.",
  bio: "Computer Science undergraduate specializing in Cyber Security, skilled in Java, Python, JavaScript, React.js, Spring Boot, and MySQL. Strong foundation in DSA, OOP, REST APIs, network security, and secure coding. Familiar with Git, SDLC, AWS, and Azure, with a focus on developing secure, scalable applications.",
  email: "mdshaiquealam710@gmail.com",
  github: "https://github.com/mdshaiquealam",
  linkedin: "https://www.linkedin.com/in/md-shaique-alam/",
  availabilityBadge: "Open to Internship & Full-Time Opportunities",
  location: "Samastipur, Bihar, India",
  interests: [
    "Cyber Security & Secure Coding",
    "Java Full Stack Development (QSpiders)",
    "Spring Boot & REST APIs",
    "Data Structures & Algorithms",
    "Network Security & Cryptography",
    "Cloud Platforms (AWS, Azure)"
  ],
  stats: [
    { label: "College", value: "GEC Samastipur" },
    { label: "Specialization", value: "Cyber Security" },
    { label: "Core Stack", value: "Java, Spring Boot, React.js" },
    { label: "Training", value: "QSpiders Java Full Stack" }
  ]
};

export const skillsData = {
  categories: [
    { id: "all", name: "All Skills" },
    { id: "languages", name: "Languages" },
    { id: "frontend", name: "Front-End" },
    { id: "backend", name: "Back-End" },
    { id: "database", name: "Database" },
    { id: "concepts", name: "Concepts & Cloud" },
    { id: "tools", name: "Tools" }
  ],
  skills: [
    // Languages
    {
      name: "Java",
      category: "languages",
      proficiency: 92,
      level: "Advanced",
      description: "Core Java, Multithreading, Collections Framework, OOP, Exception Handling, File I/O",
      highlight: true
    },
    {
      name: "Python",
      category: "languages",
      proficiency: 88,
      level: "Advanced",
      description: "Automation scripting, Data processing, File handling, Machine learning basics",
      highlight: true
    },
    {
      name: "C++",
      category: "languages",
      proficiency: 84,
      level: "Proficient",
      description: "Standard Template Library (STL), Object-Oriented Programming, Algorithm design",
      highlight: false
    },
    {
      name: "JavaScript (ES6+)",
      category: "languages",
      proficiency: 88,
      level: "Proficient",
      description: "Async/Await, Promises, DOM Manipulation, Event Loop, Modern ES6+ syntax",
      highlight: true
    },
    {
      name: "SQL",
      category: "languages",
      proficiency: 86,
      level: "Proficient",
      description: "Complex queries, Subqueries, Joins, Indexing, Query optimization",
      highlight: false
    },

    // Front-End
    {
      name: "React",
      category: "frontend",
      proficiency: 90,
      level: "Advanced",
      description: "Component Lifecycle, Custom Hooks, State Management, Reusable UI Architecture",
      highlight: true
    },
    {
      name: "HTML5",
      category: "frontend",
      proficiency: 94,
      level: "Advanced",
      description: "Semantic markup, Accessibility (a11y), SEO-optimized structures",
      highlight: false
    },
    {
      name: "CSS3 & Tailwind",
      category: "frontend",
      proficiency: 90,
      level: "Advanced",
      description: "Flexbox, CSS Grid, Responsive Design, Animations, Glassmorphism",
      highlight: false
    },
    {
      name: "Responsive Web Design",
      category: "frontend",
      proficiency: 92,
      level: "Advanced",
      description: "Mobile-first layouts, Cross-browser compatibility, Performance optimization",
      highlight: false
    },

    // Back-End
    {
      name: "Spring Boot",
      category: "backend",
      proficiency: 88,
      level: "Advanced",
      description: "Spring MVC, Spring Data JPA, Dependency Injection, Role-Based Access Control (RBAC)",
      highlight: true
    },
    {
      name: "REST APIs",
      category: "backend",
      proficiency: 90,
      level: "Advanced",
      description: "RESTful architecture, Endpoint design, Input sanitization, Error handling, JSON serialization",
      highlight: true
    },
    {
      name: "Postman",
      category: "backend",
      proficiency: 86,
      level: "Proficient",
      description: "API testing, Request chaining, Mock servers, Environment variables, Automated tests",
      highlight: false
    },

    // Database
    {
      name: "MySQL",
      category: "database",
      proficiency: 88,
      level: "Proficient",
      description: "Relational schema design, Normalization (1NF-BCNF), Constraints, Stored procedures",
      highlight: true
    },
    {
      name: "DBMS",
      category: "database",
      proficiency: 87,
      level: "Proficient",
      description: "ACID properties, Transaction management, Concurrency control, ER modeling",
      highlight: false
    },

    // Concepts & Cloud
    {
      name: "Data Structures & Algorithms (DSA)",
      category: "concepts",
      proficiency: 88,
      level: "Advanced",
      description: "Arrays, Linked Lists, Stacks, Queues, Trees, Graphs, Sorting & Searching",
      highlight: true
    },
    {
      name: "Object-Oriented Programming (OOP)",
      category: "concepts",
      proficiency: 94,
      level: "Advanced",
      description: "Encapsulation, Inheritance, Polymorphism, Abstraction, SOLID principles",
      highlight: true
    },
    {
      name: "SDLC & Agile",
      category: "concepts",
      proficiency: 85,
      level: "Proficient",
      description: "Software development lifecycle, Sprint planning, Requirement gathering, Code reviews",
      highlight: false
    },
    {
      name: "Network Security & Secure Coding",
      category: "concepts",
      proficiency: 89,
      level: "Advanced",
      description: "Mitigating OWASP Top 10 vulnerabilities (XSS, SQLi), access control, input sanitization, network protocols",
      highlight: true
    },
    {
      name: "Cloud Platforms (AWS & Azure)",
      category: "concepts",
      proficiency: 78,
      level: "Intermediate",
      description: "Cloud fundamentals, App deployment, Virtual machines, Storage, Cloud security",
      highlight: false
    },

    // Tools
    {
      name: "Git & GitHub",
      category: "tools",
      proficiency: 90,
      level: "Advanced",
      description: "Version control, Branching strategies, Pull requests, Merge conflict resolution",
      highlight: true
    },
    {
      name: "VS Code & Eclipse",
      category: "tools",
      proficiency: 90,
      level: "Advanced",
      description: "Development environments, Debugging, Extensions, Maven integration",
      highlight: false
    }
  ]
};

export const projectsData = [
  {
    id: "doctor-appointment-system",
    title: "Doctor Appointment Management System",
    category: "Java & Spring Boot Full Stack",
    isExample: false,
    badge: "Featured Full Stack Project",
    year: "2025",
    description: "Full-stack healthcare appointment scheduling system built with Java, Spring Boot, and MySQL featuring doctor slot booking, role-based access control, and patient consultation records.",
    detailedOverview: "Engineered an end-to-end Doctor Appointment Management System using Java, Spring Boot, and MySQL. Designed comprehensive modules for Patients, Doctors, and Administrators with secure authentication. Implemented appointment scheduling logic with real-time slot conflict prevention, doctor availability tracking, and automated consultation history records.",
    technologies: ["Java", "Spring Boot", "MySQL", "REST APIs", "Hibernate / JPA", "Role-Based Access Control"],
    features: [
      "Engineered full-stack appointment scheduling system in Java and Spring Boot with Role-Based Access Control (RBAC) across Patients, Doctors, and Admin",
      "Designed real-time slot booking and conflict resolution algorithms to eliminate double-booking across physician schedules",
      "Constructed normalized MySQL relational database schema for doctor profiles, specialties, appointment slots, and patient medical histories",
      "Implemented RESTful APIs for appointment status tracking (Pending, Confirmed, Cancelled, Completed) with secure input validation"
    ],
    github: "https://github.com/mdshaiquealam",
    liveDemo: null,
    demoNote: "Featured project."
  },
  {
    id: "secure-dashboard-ui",
    title: "Secure Dashboard UI",
    category: "React & Security",
    isExample: false,
    badge: "Featured React Dashboard",
    year: "2025",
    description: "A security monitoring dashboard with real-time charts using React and JavaScript, enabling instant visualization of system activity and security alerts.",
    detailedOverview: "Designed and engineered a modular security operations dashboard. Created real-time chart visualizations to track network telemetry, threat anomalies, and login activity. Constructed a proprietary reusable React component library that accelerated feature delivery by 25% while strictly enforcing session management and role-gated UI elements.",
    technologies: ["React", "JavaScript (ES6+)", "HTML5", "CSS3", "Chart UI", "Session Management"],
    features: [
      "Built security monitoring dashboard with real-time charts using React and JavaScript, enabling instant visualization of system activity and security alerts",
      "Developed reusable React component library, reducing feature development time by 25% and ensuring design consistency",
      "Implemented session management and role-based UI rendering, restricting sensitive data views to authorized users only",
      "Optimized DOM rendering and component-level memoization for fluid interactions"
    ],
    github: "https://github.com/mdshaiquealam",
    liveDemo: null,
    demoNote: "Featured project from official resume."
  },
  {
    id: "bank-management-system",
    title: "Bank Management System",
    category: "Java / Core Backend",
    isExample: true,
    badge: "Core Java & OOP",
    year: "2024",
    description: "A robust banking application built in Java simulating core bank operations with account creation, deposits, withdrawals, fund transfers, and balance inquiries.",
    detailedOverview: "Engineered a command-line & modular banking platform in Java. Designed account models with validation checks for minimum balances and overdraft protection. Implemented transaction history logging and account state management adhering to object-oriented encapsulation.",
    technologies: ["Java", "OOP", "Collections Framework", "File I/O", "Exception Handling"],
    features: [
      "User authentication and secure PIN validation",
      "Account types: Savings & Current with tailored interest and limit rules",
      "Real-time deposit, withdrawal, and inter-account funds transfer",
      "Transaction history tracking and statement generation"
    ],
    github: "https://github.com/mdshaiquealam",
    liveDemo: null,
    demoNote: "Example project from coursework."
  },
  {
    id: "personal-portfolio-website",
    title: "Modern Developer Portfolio",
    category: "Frontend & Full Stack",
    isExample: false,
    badge: "Live Project",
    year: "2025",
    description: "A modern developer portfolio built with React, Vite, Tailwind CSS, and Framer Motion featuring interactive components, glassmorphism, and theme switching.",
    detailedOverview: "Designed and implemented this sleek, dark-themed personal portfolio with smooth entrance animations, interactive skill metrics, project modal previews, and complete configuration abstraction for effortless profile maintenance.",
    technologies: ["React", "Vite", "Tailwind CSS", "Framer Motion", "Canvas Confetti"],
    features: [
      "Dark and Light theme toggle with persisted user preference",
      "Responsive glassmorphism design optimized for all screen sizes",
      "Interactive Java code visualizer and resume preview with print styling",
      "Client-side validated contact form and direct mail integration"
    ],
    github: "https://github.com/mdshaiquealam",
    liveDemo: "#",
    demoNote: "Currently viewing this application!"
  }
];

export const educationData = [
  {
    degree: "B.Tech in Computer Science and Engineering",
    institution: "Government Engineering College Samastipur",
    location: "Samastipur, Bihar, India",
    duration: "2022 – 2026",
    status: "Currently Pursuing (Undergraduate)",
    isPlaceholder: false,
    description: "Comprehensive undergraduate engineering program covering core computer science principles, software architecture, algorithmic design, and full-stack software development.",
    coursework: [
      "Data Structures & Algorithms",
      "Object-Oriented Programming (OOP)",
      "Database Management Systems (DBMS)",
      "Operating Systems",
      "Computer Networks",
      "Software Development Life Cycle (SDLC)",
      "REST API Design & Web Engineering"
    ]
  }
];

export const experienceData = {
  sectionNote: "Verified work experience, QSpiders Java Full Stack training, and accredited industry certifications.",
  internships: [
    {
      role: "Web Development Intern",
      company: "Octanet Services Pvt Ltd",
      duration: "Jun 2024 – Jul 2024",
      location: "Remote",
      isPlaceholder: false,
      badge: "Industry Internship",
      description: "Engineered responsive user interfaces, integrated secure REST APIs, and implemented comprehensive frontend security protocols.",
      highlights: [
        "Engineered 5+ responsive UI pages using HTML5, CSS3, and JavaScript, reducing page load time by 20% through component-level optimization",
        "Implemented secure authentication and form validation protocols, mitigating input-based vulnerabilities (XSS, injection) across the application",
        "Integrated REST APIs with input sanitization and error handling, ensuring secure client-server data transmission across all endpoints"
      ],
      technologies: ["HTML5", "CSS3", "JavaScript", "REST APIs", "Form Validation", "Web Security"]
    }
  ],
  certifications: [
    {
      title: "Java Full Stack Development Training",
      issuer: "QSpiders",
      category: "Java Full Stack & J2EE",
      badge: "Professional Training",
      date: "Completed",
      credentialId: "QSPIDERS-JAVA-FS",
      description: "Comprehensive industry training program covering Core Java, J2EE, Spring Boot, Hibernate ORM, RESTful Microservices, SQL/MySQL database architecture, and modern frontend web engineering."
    },
    {
      title: "Object-Oriented Programming",
      issuer: "NPTEL (National Programme on Technology Enhanced Learning)",
      category: "Core Computer Science",
      badge: "Academic Excellence",
      date: "Certified",
      credentialId: "NPTEL-OOP-VERIFIED",
      description: "Comprehensive certification verifying mastery of object-oriented concepts, design patterns, encapsulation, polymorphism, inheritance, and abstraction in software design."
    },
    {
      title: "Geodata Processing using Python and Machine Learning",
      issuer: "ISRO (Indian Space Research Organisation / IIRS)",
      category: "Python & Machine Learning",
      badge: "Prestigious Govt. Agency",
      date: "Certified",
      credentialId: "ISRO-IIRS-PYTHON-ML",
      description: "Advanced program conducted by ISRO/IIRS covering geospatial data analytics, satellite image processing pipelines, and applied machine learning models using Python."
    },
    {
      title: "Python Programming",
      issuer: "Cisco Networking Academy",
      category: "Programming & Algorithms",
      badge: "Cisco Certified",
      date: "Certified",
      credentialId: "CISCO-PYTHON-PROG",
      description: "Industry-standard certification validating competency in Python syntax, data structures, modular software development, and algorithm implementation."
    },
    {
      title: "Cybersecurity Essentials",
      issuer: "Cisco Networking Academy",
      category: "Information Security",
      badge: "Cisco Certified",
      date: "Certified",
      credentialId: "CISCO-CYBER-ESSENTIALS",
      description: "Fundamental security principles covering network defense techniques, data confidentiality, threat analysis, cryptography basics, and system integrity."
    },
    {
      title: "CCNA (Cisco Certified Network Associate)",
      issuer: "Cisco Networking Academy",
      category: "Computer Networks & Routing",
      badge: "Cisco Certified",
      date: "Certified",
      credentialId: "CISCO-CCNA-NETWORKS",
      description: "Rigorous network engineering curriculum covering IP connectivity, OSI/TCP-IP models, subnetting, network security, switching, and routing protocols."
    }
  ]
};

export const codingProfiles = [
  {
    name: "GitHub",
    handle: "mdshaiquealam",
    url: "https://github.com/mdshaiquealam",
    color: "#a855f7",
    category: "Code & Projects",
    description: "Explore my open-source repositories, full-stack projects, and Java codebases."
  },
  {
    name: "LinkedIn",
    handle: "md-shaique-alam",
    url: "https://www.linkedin.com/in/md-shaique-alam/",
    color: "#0077b5",
    category: "Professional Network",
    description: "Connect with me for professional updates, internship opportunities, and industry insights."
  },
  {
    name: "LeetCode",
    handle: "mdshaiquealam",
    url: "https://leetcode.com/",
    color: "#f59e0b",
    category: "Problem Solving",
    description: "Algorithmic problem-solving practice covering data structures and problem patterns."
  },
  {
    name: "GeeksforGeeks",
    handle: "mdshaiquealam",
    url: "https://www.geeksforgeeks.org/",
    color: "#10b981",
    category: "DSA & Computer Science",
    description: "Practicing coding challenges, company-specific questions, and CS fundamentals."
  },
  {
    name: "HackerRank",
    handle: "mdshaiquealam",
    url: "https://www.hackerrank.com/",
    color: "#06b6d4",
    category: "Skill Verification",
    description: "Problem-solving badges and language proficiency in Java, Python, and Problem Solving."
  }
];

export const sampleJavaCodeSnippet = `public class Developer implements FullStackDeveloper {
    private final String name = "Md Shaique Alam";
    private final String college = "Government Engineering College Samastipur";
    private final String training = "QSpiders Java Full Stack Development";
    private final String[] coreStack = {"Java", "Spring Boot", "React", "Python", "MySQL"};

    @Override
    public void buildImpactfulSolutions() {
        System.out.println("Building secure back-end systems & responsive front-ends.");
    }

    public boolean isOpenForOpportunities() {
        return true; // Eager to learn, contribute, and innovate!
    }
}`;
