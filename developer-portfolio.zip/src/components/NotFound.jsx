import React from 'react';
import { Home, ArrowLeft, Terminal, AlertTriangle } from 'lucide-react';

export default function NotFound({ onGoHome }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50 dark:bg-[#070709] text-slate-900 dark:text-white">
      <div className="max-w-md w-full text-center p-8 rounded-2xl bg-white/70 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200 dark:border-white/10 shadow-2xl">
        <div className="w-16 h-16 rounded-2xl bg-brand-500/10 border border-brand-500/20 text-brand-500 flex items-center justify-center mx-auto mb-6">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <span className="font-mono text-sm text-brand-500 font-semibold tracking-wider">
          ERROR 404
        </span>
        <h1 className="text-3xl font-extrabold mt-1 mb-3">
          Page Not Found
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mb-8 leading-relaxed">
          The requested resource could not be found or has been moved. Let's get you back to the main developer portfolio.
        </p>

        <button
          onClick={onGoHome || (() => window.location.href = '/')}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold bg-brand-600 hover:bg-brand-500 text-white shadow-lg shadow-brand-500/25 transition-all"
        >
          <Home className="w-4 h-4" />
          <span>Return to Portfolio</span>
        </button>
      </div>
    </div>
  );
}
