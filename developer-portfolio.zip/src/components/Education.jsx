import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Calendar, MapPin, Award, BookOpen, CheckCircle } from 'lucide-react';
import { educationData } from '../data/portfolioData';

export default function Education() {
  return (
    <section id="education" className="py-24 relative overflow-hidden bg-slate-50/50 dark:bg-black/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Academic Background</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Education &amp; <span className="gradient-text">Qualifications</span>
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
            Foundational computer science degree curriculum combining theoretical computation, system architectures, and practical programming labs.
          </p>
        </div>

        {/* Timeline Container */}
        <div className="max-w-3xl mx-auto">
          {educationData.map((edu, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="relative pl-8 sm:pl-10 border-l-2 border-brand-500/30 pb-8 last:pb-0"
            >
              {/* Glowing timeline node */}
              <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-gradient-to-tr from-brand-600 to-indigo-600 ring-4 ring-white dark:ring-[#070709] shadow-md shadow-brand-500/50" />

              {/* Education Card */}
              <div className="rounded-2xl p-6 sm:p-8 bg-white/80 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 shadow-lg shadow-slate-200/50 dark:shadow-none">
                
                {/* Degree & Status */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-brand-500/15 text-brand-600 dark:text-brand-400 border border-brand-500/30">
                    {edu.status}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500 dark:text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-brand-500" />
                    <span>{edu.duration}</span>
                  </div>
                </div>

                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-2">
                  {edu.degree}
                </h3>

                {/* Institution & Location */}
                <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium mb-4">
                  <div className="flex items-center gap-1.5 text-slate-900 dark:text-white font-semibold">
                    <span className="text-brand-500 font-bold">@</span>
                    <span>{edu.institution}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-400">
                    <MapPin className="w-3.5 h-3.5 text-brand-500" />
                    <span>{edu.location}</span>
                  </div>
                </div>

                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                  {edu.description}
                </p>

                {/* Relevant Coursework Badges */}
                <div>
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-brand-500" />
                    <span>Key Coursework &amp; Academic Focus</span>
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {edu.coursework.map((course) => (
                      <span
                        key={course}
                        className="px-3 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/10"
                      >
                        {course}
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
