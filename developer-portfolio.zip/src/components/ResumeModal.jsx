import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Printer, 
  FileText, 
  Mail, 
  Phone, 
  ExternalLink,
  CheckCircle2,
  Sparkles,
  Download
} from 'lucide-react';
import { GithubIcon, LinkedinIcon } from './Icons';
import confetti from 'canvas-confetti';
import { personalInfo, educationData, experienceData, projectsData } from '../data/portfolioData';

export default function ResumeModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  // Method 1: In-place 1-page print
  const handlePrint = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch (e) {}

    window.print();
  };

  // Method 2: Dedicated isolated 1-page printable window
  const handlePrintIsolated = () => {
    const printWindow = window.open('', '_blank', 'width=850,height=1100');
    if (!printWindow) {
      window.print();
      return;
    }

    const isolatedHtml = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>${personalInfo.name} - Resume (1 Page)</title>
        <style>
          @page {
            size: A4 portrait;
            margin: 8mm 10mm 6mm 10mm;
          }
          * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            page-break-inside: avoid;
            break-inside: avoid;
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            color: #000;
            background: #fff;
            font-size: 8.5pt;
            line-height: 1.25;
            padding: 0;
          }
          .resume-container {
            width: 100%;
            max-width: 100%;
            margin: 0 auto;
          }
          .header {
            text-align: center;
            border-bottom: 1.5px solid #000;
            padding-bottom: 3px;
            margin-bottom: 5px;
          }
          .name {
            font-size: 20pt;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 2px;
            font-family: Georgia, serif;
          }
          .contact {
            font-size: 8.5pt;
            color: #111;
          }
          .contact a {
            color: inherit;
            text-decoration: none;
          }
          .section {
            margin-bottom: 5px;
          }
          .section-title {
            font-size: 9pt;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid #222;
            padding-bottom: 1px;
            margin-bottom: 2.5px;
          }
          .row {
            display: flex;
            justify-content: space-between;
            align-items: baseline;
            font-size: 8.5pt;
            font-weight: bold;
          }
          .sub {
            font-size: 8.2pt;
            font-style: italic;
            color: #222;
            margin-bottom: 1px;
          }
          .bullets {
            padding-left: 14px;
            margin-top: 1px;
            margin-bottom: 2px;
          }
          .bullets li {
            font-size: 8.2pt;
            line-height: 1.25;
            margin-bottom: 1.5px;
            color: #111;
          }
          .skills-line {
            font-size: 8.3pt;
            line-height: 1.25;
            margin-bottom: 1.5px;
          }
          .skills-line strong {
            color: #000;
          }
          .summary {
            font-size: 8.3pt;
            line-height: 1.25;
            color: #111;
            text-align: justify;
          }
        </style>
      </head>
      <body>
        <div class="resume-container">
          <div class="header">
            <div class="name">${personalInfo.name}</div>
            <div class="contact">
              ${personalInfo.phone} &nbsp;|&nbsp;
              ${personalInfo.email} &nbsp;|&nbsp;
              linkedin.com/in/md-shaique-alam &nbsp;|&nbsp;
              github.com/mdshaiquealam
            </div>
          </div>

          <div class="section">
            <div class="section-title">Professional Summary</div>
            <div class="summary">${personalInfo.bio}</div>
          </div>

          <div class="section">
            <div class="section-title">Education</div>
            <div class="row">
              <span>${personalInfo.college}</span>
              <span style="font-weight: normal; font-size: 8pt;">${personalInfo.batch}</span>
            </div>
            <div class="sub">${personalInfo.education}</div>
          </div>

          <div class="section">
            <div class="section-title">Technical Skills</div>
            <div class="skills-line"><strong>Languages:</strong> Python, C++, JavaScript, SQL, Java</div>
            <div class="skills-line"><strong>Front-End:</strong> React, HTML5, CSS3, Responsive Web Design</div>
            <div class="skills-line"><strong>Back-End:</strong> Spring Boot, REST APIs, Postman</div>
            <div class="skills-line"><strong>Database:</strong> MySQL, DBMS</div>
            <div class="skills-line"><strong>Concepts:</strong> Data Structures & Algorithms, Object-Oriented Programming (OOP), Network Security, SDLC</div>
          </div>

          <div class="section">
            <div class="section-title">Work Experience</div>
            <div>
              <div class="row">
                <span>Octanet Services Pvt Ltd</span>
                <span style="font-weight: normal; font-size: 8pt;">Jun 2024 – Jul 2024</span>
              </div>
              <div class="sub">Web Development Intern</div>
              <ul class="bullets">
                <li>Engineered 5+ responsive UI pages using HTML5, CSS3, and JavaScript, reducing page load time by 20% through component-level optimization</li>
                <li>Implemented secure authentication and form validation protocols, mitigating input-based vulnerabilities (XSS, injection) across the application</li>
                <li>Integrated REST APIs with input sanitization and error handling, ensuring secure client-server data transmission across all endpoints</li>
              </ul>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Projects</div>
            <div style="margin-bottom: 3px;">
              <div class="row">
                <span>Doctor Appointment Management System <span style="font-weight: normal; font-style: italic;">| Java, Spring Boot, MySQL</span></span>
                <span style="font-weight: normal; font-size: 8pt;">2025</span>
              </div>
              <ul class="bullets">
                <li>Engineered full-stack appointment scheduling system in Java and Spring Boot with Role-Based Access Control (RBAC) across Patients, Doctors, and Admin</li>
                <li>Designed real-time slot booking and conflict resolution algorithms to eliminate double-booking across physician schedules</li>
                <li>Constructed normalized MySQL relational database schema for doctor profiles, specialties, appointment slots, and patient medical histories</li>
              </ul>
            </div>

            <div>
              <div class="row">
                <span>Secure Dashboard UI <span style="font-weight: normal; font-style: italic;">| React, JavaScript, HTML, CSS</span></span>
                <span style="font-weight: normal; font-size: 8pt;">2025</span>
              </div>
              <ul class="bullets">
                <li>Built security monitoring dashboard with real-time charts using React and JavaScript, enabling instant visualization of system activity and security alerts</li>
                <li>Developed reusable React component library, reducing feature development time by 25% and ensuring design consistency</li>
                <li>Implemented session management and role-based UI rendering, restricting sensitive data views to authorized users only</li>
              </ul>
            </div>
          </div>

          <div class="section">
            <div class="section-title">Certifications &amp; Training</div>
            <div class="skills-line"><strong>QSpiders:</strong> Java Full Stack Development Training (Core Java, Spring Boot, Hibernate, SQL, React)</div>
            <div class="skills-line"><strong>NPTEL:</strong> Object-Oriented Programming</div>
            <div class="skills-line"><strong>ISRO:</strong> Geodata Processing using Python and Machine Learning</div>
            <div class="skills-line"><strong>Cisco Networking Academy:</strong> Python Programming | Cybersecurity Essentials | CCNA</div>
          </div>
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(isolatedHtml);
    printWindow.document.close();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-md overflow-y-auto resume-modal-overlay">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl bg-white dark:bg-[#0c0d14] border border-slate-200 dark:border-white/15 p-5 sm:p-8 shadow-2xl text-slate-800 dark:text-slate-200 resume-modal-card"
        >
          {/* Header controls (hidden when printing) */}
          <div className="pb-4 mb-4 border-b border-slate-200 dark:border-white/10 print-hide">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-brand-500" />
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                  Official Resume &bull; {personalInfo.name}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
                  Strict 1-Page Fit
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white transition-all shadow-md shadow-brand-500/25 active:scale-95"
                  title="Save or Print as a 1-page PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Save as 1-Page PDF</span>
                </button>

                <button
                  onClick={handlePrintIsolated}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-white/15 bg-slate-100/80 dark:bg-white/5 hover:bg-slate-200 dark:hover:bg-white/10 text-slate-700 dark:text-slate-300 transition-all"
                  title="Open isolated 1-page printable tab"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Isolated View</span>
                </button>

                <button
                  onClick={onClose}
                  aria-label="Close Resume Preview"
                  className="p-2 rounded-xl bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300 hover:text-black dark:hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Instruction Banner */}
            <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs flex items-center justify-between gap-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>
                  <strong>Guaranteed 1-Page PDF:</strong> Set Destination to <em>"Save as PDF"</em>. Margins are pre-calibrated to fit on a single page!
                </span>
              </span>
            </div>
          </div>

          {/* Printable Resume Document */}
          <div className="one-page-resume-root font-sans bg-white dark:bg-[#0c0d14] p-3 sm:p-5 rounded-xl print:p-0 print:bg-white print:text-black">
            
            {/* Header: Name & Contact Row */}
            <div className="resume-print-header text-center border-b border-slate-300 dark:border-white/10 pb-3 mb-4 print:border-black">
              <h1 className="resume-print-name text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white print:text-black font-serif">
                {personalInfo.name}
              </h1>

              <div className="resume-print-contact flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs text-slate-700 dark:text-slate-300 print:text-black mt-1.5 font-mono">
                <a href={`tel:${personalInfo.phone}`} className="flex items-center gap-1 hover:text-brand-500">
                  <Phone className="w-3 h-3 text-brand-500 print:text-black" />
                  <span>{personalInfo.phone}</span>
                </a>
                <span>|</span>
                <a href={`mailto:${personalInfo.email}`} className="flex items-center gap-1 hover:text-brand-500">
                  <Mail className="w-3 h-3 text-brand-500 print:text-black" />
                  <span>{personalInfo.email}</span>
                </a>
                <span>|</span>
                <a href={personalInfo.linkedin} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-brand-500">
                  <LinkedinIcon className="w-3 h-3 text-[#0077b5] print:text-black" />
                  <span>linkedin.com/in/md-shaique-alam</span>
                </a>
                <span>|</span>
                <a href={personalInfo.github} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-brand-500">
                  <GithubIcon className="w-3 h-3 print:text-black" />
                  <span>github.com/mdshaiquealam</span>
                </a>
              </div>
            </div>

            {/* Professional Summary */}
            <div className="resume-section mb-4">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                PROFESSIONAL SUMMARY
              </h2>
              <p className="resume-text-body text-xs sm:text-[12.5px] text-slate-700 dark:text-slate-300 print:text-black leading-relaxed">
                {personalInfo.bio}
              </p>
            </div>

            {/* Education */}
            <div className="resume-section mb-4">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                EDUCATION
              </h2>
              <div className="resume-sub-heading flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[12.5px]">
                <strong className="text-slate-900 dark:text-white print:text-black font-bold">
                  {personalInfo.college}
                </strong>
                <span className="text-slate-600 dark:text-slate-400 print:text-black font-mono text-xs">
                  {personalInfo.batch}
                </span>
              </div>
              <div className="resume-role-sub text-xs sm:text-[12px] text-slate-700 dark:text-slate-300 print:text-black italic">
                {personalInfo.education}
              </div>
            </div>

            {/* Technical Skills */}
            <div className="resume-section mb-4">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                TECHNICAL SKILLS
              </h2>
              <div className="space-y-1 text-xs sm:text-[12.5px] leading-relaxed">
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Languages: </strong>
                  <span className="text-slate-700 dark:text-slate-300 print:text-black">Python, C++, JavaScript, SQL, Java</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Front-End: </strong>
                  <span className="text-slate-700 dark:text-slate-300 print:text-black">React, HTML5, CSS3, Responsive Web Design</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Back-End: </strong>
                  <span className="text-slate-700 dark:text-slate-300 print:text-black">Spring Boot, REST APIs, Postman</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Database: </strong>
                  <span className="text-slate-700 dark:text-slate-300 print:text-black">MySQL, DBMS</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Concepts: </strong>
                  <span className="text-slate-700 dark:text-slate-300 print:text-black">Data Structures &amp; Algorithms, Object-Oriented Programming (OOP), Network Security, SDLC</span>
                </div>
              </div>
            </div>

            {/* Work Experience */}
            <div className="resume-section mb-4">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                WORK EXPERIENCE
              </h2>
              <div>
                {/* Octanet Services */}
                <div>
                  <div className="resume-sub-heading flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[12.5px]">
                    <strong className="text-slate-900 dark:text-white print:text-black font-bold">
                      Octanet Services Pvt Ltd
                    </strong>
                    <span className="text-slate-600 dark:text-slate-400 print:text-black font-mono text-xs">
                      Jun 2024 – Jul 2024
                    </span>
                  </div>
                  <div className="resume-role-sub text-xs italic text-brand-600 dark:text-brand-400 print:text-black mb-0.5">
                    Web Development Intern
                  </div>
                  <ul className="resume-bullet-list list-disc list-outside pl-4 space-y-0.5 text-xs sm:text-[12px] text-slate-700 dark:text-slate-300 print:text-black">
                    <li>Engineered 5+ responsive UI pages using HTML5, CSS3, and JavaScript, reducing page load time by 20% through component-level optimization</li>
                    <li>Implemented secure authentication and form validation protocols, mitigating input-based vulnerabilities (XSS, injection) across the application</li>
                    <li>Integrated REST APIs with input sanitization and error handling, ensuring secure client-server data transmission across all endpoints</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Projects */}
            <div className="resume-section mb-4">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                PROJECTS
              </h2>
              <div className="space-y-2.5">
                {/* Doctor Appointment System */}
                <div>
                  <div className="resume-sub-heading flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[12.5px]">
                    <div className="text-slate-900 dark:text-white print:text-black">
                      <strong className="font-bold">Doctor Appointment Management System</strong>
                      <span className="italic text-slate-600 dark:text-slate-400 print:text-black"> | Java, Spring Boot, MySQL</span>
                    </div>
                    <span className="text-slate-600 dark:text-slate-400 print:text-black font-mono text-xs">
                      2025
                    </span>
                  </div>
                  <ul className="resume-bullet-list list-disc list-outside pl-4 space-y-0.5 text-xs sm:text-[12px] text-slate-700 dark:text-slate-300 print:text-black mt-0.5">
                    <li>Engineered full-stack appointment scheduling system in Java and Spring Boot with Role-Based Access Control (RBAC) across Patients, Doctors, and Admin</li>
                    <li>Designed real-time slot booking and conflict resolution algorithms to eliminate double-booking across physician schedules</li>
                    <li>Constructed normalized MySQL relational database schema for doctor profiles, specialties, appointment slots, and patient medical histories</li>
                  </ul>
                </div>

                {/* Secure Dashboard UI */}
                <div>
                  <div className="resume-sub-heading flex flex-col sm:flex-row sm:items-center justify-between text-xs sm:text-[12.5px]">
                    <div className="text-slate-900 dark:text-white print:text-black">
                      <strong className="font-bold">Secure Dashboard UI</strong>
                      <span className="italic text-slate-600 dark:text-slate-400 print:text-black"> | React, JavaScript, HTML, CSS</span>
                    </div>
                    <span className="text-slate-600 dark:text-slate-400 print:text-black font-mono text-xs">
                      2025
                    </span>
                  </div>
                  <ul className="resume-bullet-list list-disc list-outside pl-4 space-y-0.5 text-xs sm:text-[12px] text-slate-700 dark:text-slate-300 print:text-black mt-0.5">
                    <li>Built security monitoring dashboard with real-time charts using React and JavaScript, enabling instant visualization of system activity and security alerts</li>
                    <li>Developed reusable React component library, reducing feature development time by 25% and ensuring design consistency</li>
                    <li>Implemented session management and role-based UI rendering, restricting sensitive data views to authorized users only</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Certifications & Training */}
            <div className="resume-section">
              <h2 className="resume-section-title text-xs uppercase tracking-wider font-bold text-slate-900 dark:text-white print:text-black border-b border-slate-300 dark:border-white/15 print:border-black pb-0.5 mb-1.5 font-mono">
                CERTIFICATIONS &amp; TRAINING
              </h2>
              <div className="space-y-1 text-xs sm:text-[12px] text-slate-700 dark:text-slate-300 print:text-black">
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">QSpiders: </strong>
                  <span>Java Full Stack Development Training (Core Java, Spring Boot, Hibernate, SQL, React)</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">NPTEL: </strong>
                  <span>Object-Oriented Programming</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">ISRO: </strong>
                  <span>Geodata Processing using Python and Machine Learning</span>
                </div>
                <div className="resume-text-body">
                  <strong className="text-slate-900 dark:text-white print:text-black">Cisco Networking Academy: </strong>
                  <span>Python Programming | Cybersecurity Essentials | CCNA</span>
                </div>
              </div>
            </div>

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
