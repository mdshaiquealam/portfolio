import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowRight, 
  FileText, 
  Mail, 
  Terminal, 
  Play, 
  Check, 
  Copy, 
  Sparkles,
  Code2,
  Cpu,
  Layers
} from 'lucide-react';
import { GithubIcon, LinkedinIcon } from './Icons';
import { personalInfo, sampleJavaCodeSnippet } from '../data/portfolioData';

export default function Hero({ onOpenResume }) {
  const [copiedCode, setCopiedCode] = useState(false);
  const [isRunningCode, setIsRunningCode] = useState(false);
  const [codeOutput, setCodeOutput] = useState(null);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(sampleJavaCodeSnippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleRunCode = () => {
    setIsRunningCode(true);
    setTimeout(() => {
      setIsRunningCode(false);
      setCodeOutput({
        status: "Compiled & Executed Successfully in JVM 21",
        result: "Building secure back-end systems & responsive front-ends.\nCollege: Government Engineering College Samastipur (2022-26)\nTraining: QSpiders Java Full Stack Development\nInternship: Web Development Intern @ Octanet Services\nCertifications: ISRO | NPTEL | Cisco (CCNA, Security, Python)"
      });
    }, 700);
  };

  return (
    <section 
      id="hero" 
      className="relative min-h-[92vh] flex items-center justify-center pt-28 pb-16 overflow-hidden"
    >
      {/* Background ambient lighting orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-brand-600/15 dark:bg-brand-600/20 blur-[130px] rounded-full pointer-events-none -z-10" />
      <div className="absolute top-1/3 left-10 w-[300px] h-[300px] bg-blue-500/10 dark:bg-blue-600/15 blur-[120px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-10 w-[350px] h-[350px] bg-purple-600/10 dark:bg-purple-600/15 blur-[120px] rounded-full pointer-events-none -z-10" />

      {/* Grid Pattern Background Overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:28px_28px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Introductions & CTAs (7 cols) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7 flex flex-col items-start text-left"
          >
            {/* Availability Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-semibold tracking-wide mb-6 shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>{personalInfo.availabilityBadge}</span>
            </div>

            {/* Name Greeting */}
            <h2 className="text-sm uppercase tracking-widest font-mono font-medium text-brand-600 dark:text-brand-400 mb-2">
              Hello, World! I am
            </h2>

            {/* Prominent Name */}
            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white mb-4">
              <span className="block">{personalInfo.name}</span>
              <span className="text-2xl sm:text-3xl md:text-4xl block mt-1 font-semibold gradient-text">
                {personalInfo.role}
              </span>
            </h1>

            {/* Headline */}
            <p className="text-lg sm:text-xl font-medium text-slate-700 dark:text-slate-300 mb-4 leading-relaxed">
              {personalInfo.headline}
            </p>

            {/* Description */}
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mb-8 max-w-2xl leading-relaxed">
              {personalInfo.bio}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 mb-9 w-full sm:w-auto">
              {/* View Projects */}
              <a
                href="#projects"
                className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold bg-gradient-to-r from-brand-600 via-indigo-600 to-purple-600 text-white shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
              >
                <span>View My Projects</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              {/* Download Resume */}
              <button
                onClick={onOpenResume}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold border border-slate-300 dark:border-white/15 bg-white/70 dark:bg-white/5 text-slate-800 dark:text-slate-200 hover:border-brand-500/50 hover:bg-slate-100 dark:hover:bg-white/10 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 backdrop-blur-sm shadow-sm"
              >
                <FileText className="w-4 h-4 text-brand-500" />
                <span>Download Resume</span>
              </button>

              {/* Contact Me */}
              <a
                href="#contact"
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold border border-transparent text-slate-700 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-slate-100 dark:hover:bg-white/5 transition-all duration-200"
              >
                <Mail className="w-4 h-4" />
                <span>Contact Me</span>
              </a>
            </div>

            {/* Social Links & Quick Connect */}
            <div className="flex items-center gap-4 pt-4 border-t border-slate-200 dark:border-white/10 w-full">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Connect directly:
              </span>
              <div className="flex items-center gap-2.5">
                <a
                  href={personalInfo.github}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="GitHub Profile"
                  className="p-2 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:text-white hover:bg-[#24292e] transition-colors"
                >
                  <GithubIcon className="w-4 h-4" />
                </a>
                <a
                  href={personalInfo.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="LinkedIn Profile"
                  className="p-2 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:text-white hover:bg-[#0077b5] transition-colors"
                >
                  <LinkedinIcon className="w-4 h-4" />
                </a>
                <a
                  href={`mailto:${personalInfo.email}`}
                  aria-label="Email Md Shaique Alam"
                  className="p-2 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 hover:text-white hover:bg-brand-600 transition-colors"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Interactive Code Visualizer / Illustration (5 cols) */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-5"
          >
            <div className="relative rounded-2xl overflow-hidden border border-slate-200/80 dark:border-white/15 bg-slate-900/90 dark:bg-[#0c0d14]/90 backdrop-blur-xl shadow-2xl dark:shadow-brand-950/50">
              
              {/* Window Header */}
              <div className="flex items-center justify-between px-4 py-3 bg-slate-950/70 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-2 text-xs font-mono text-slate-400 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-brand-400" />
                    Developer.java
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleCopyCode}
                    title="Copy code"
                    className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors text-xs flex items-center gap-1 font-mono"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-[11px] text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span className="text-[11px] hidden sm:inline">Copy</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleRunCode}
                    disabled={isRunningCode}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-mono font-medium bg-brand-500 hover:bg-brand-600 text-white transition-all shadow-sm disabled:opacity-50"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>{isRunningCode ? "Compiling..." : "Run"}</span>
                  </button>
                </div>
              </div>

              {/* Code Editor Body */}
              <div className="p-4 sm:p-5 font-mono text-xs sm:text-[13px] leading-relaxed text-slate-300 overflow-x-auto">
                <div>
                  <span className="text-purple-400">public class</span>{' '}
                  <span className="text-amber-300 font-semibold">Developer</span>{' '}
                  <span className="text-purple-400">implements</span>{' '}
                  <span className="text-cyan-300">FullStackDeveloper</span> &#123;
                </div>
                
                <div className="pl-4 mt-1">
                  <span className="text-slate-500 dark:text-slate-500">// Personal Information &amp; Stack</span>
                </div>
                <div className="pl-4">
                  <span className="text-purple-400">private final</span>{' '}
                  <span className="text-blue-400">String</span> name ={' '}
                  <span className="text-emerald-300">"{personalInfo.name}"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-purple-400">private final</span>{' '}
                  <span className="text-blue-400">String</span> role ={' '}
                  <span className="text-emerald-300">"{personalInfo.role}"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-purple-400">private final</span>{' '}
                  <span className="text-blue-400">String</span> training ={' '}
                  <span className="text-emerald-300">"QSpiders Java Full Stack"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-purple-400">private final</span>{' '}
                  <span className="text-blue-400">String[]</span> coreStack = &#123;
                  <span className="text-emerald-300">"Java"</span>,{' '}
                  <span className="text-emerald-300">"Spring Boot"</span>,{' '}
                  <span className="text-emerald-300">"React"</span>,{' '}
                  <span className="text-emerald-300">"Python"</span>,{' '}
                  <span className="text-emerald-300">"MySQL"</span>
                  &#125;;
                </div>

                <div className="pl-4 mt-2">
                  <span className="text-slate-400">@Override</span>
                </div>
                <div className="pl-4">
                  <span className="text-purple-400">public void</span>{' '}
                  <span className="text-amber-300">buildImpactfulSolutions</span>() &#123;
                </div>
                <div className="pl-8">
                  <span className="text-cyan-400">System</span>.out.println(
                  <span className="text-emerald-300">"Turning ideas into scalable software."</span>);
                </div>
                <div className="pl-4">&#125;</div>

                <div className="pl-4 mt-2">
                  <span className="text-purple-400">public boolean</span>{' '}
                  <span className="text-amber-300">isOpenForOpportunities</span>() &#123;
                </div>
                <div className="pl-8">
                  <span className="text-purple-400">return</span>{' '}
                  <span className="text-cyan-400">true</span>;{' '}
                  <span className="text-slate-500">// Ready to learn &amp; build!</span>
                </div>
                <div className="pl-4">&#125;</div>

                <div>&#125;</div>
              </div>

              {/* Simulated Output Terminal */}
              {codeOutput && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="border-t border-white/10 bg-black/60 p-3 sm:p-4 font-mono text-xs"
                >
                  <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>{codeOutput.status}</span>
                  </div>
                  <pre className="text-slate-300 whitespace-pre-wrap leading-snug">
                    {codeOutput.result}
                  </pre>
                </motion.div>
              )}

              {/* Floating tech badges beneath editor */}
              <div className="px-4 py-3 bg-slate-950/40 border-t border-white/5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                <span className="flex items-center gap-1 text-slate-300">
                  <Code2 className="w-3.5 h-3.5 text-brand-400" /> Java 21 LTS
                </span>
                <span className="flex items-center gap-1 text-slate-300">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" /> OOP Architecture
                </span>
                <span className="flex items-center gap-1 text-slate-300">
                  <Layers className="w-3.5 h-3.5 text-purple-400" /> Modern Web
                </span>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
