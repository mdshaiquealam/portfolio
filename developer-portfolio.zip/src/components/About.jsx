import React from 'react';
import { motion } from 'framer-motion';
import { 
  Code, 
  Terminal, 
  Database, 
  Layers, 
  CheckCircle2, 
  GraduationCap, 
  Sparkles,
  Target,
  Lightbulb,
  Workflow
} from 'lucide-react';
import { personalInfo } from '../data/portfolioData';

export default function About() {
  const coreStrengths = [
    {
      icon: Terminal,
      title: "Strong Java & OOP Core",
      description: "Thorough understanding of object-oriented principles, polymorphism, encapsulation, abstraction, and the Java Collections Framework to design modular architectures.",
      color: "from-brand-500 to-indigo-500"
    },
    {
      icon: Code,
      title: "DSA & Problem Solving",
      description: "Practicing data structures and algorithms in C++ and Java with an emphasis on time and space complexity, array manipulation, trees, and algorithmic patterns.",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Layers,
      title: "Full Stack Vision",
      description: "Bridging solid backend engineering with dynamic, user-centric web frontends built using modern JavaScript, HTML5, CSS3, and React.",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Database,
      title: "Relational Data Modeling",
      description: "Proficient in writing structured SQL queries, crafting relational schemas in MySQL, designing normalized tables, and understanding ACID compliance.",
      color: "from-emerald-500 to-teal-500"
    }
  ];

  const quickDetails = [
    { label: "College", value: "Government Engineering College Samastipur" },
    { label: "Degree & Major", value: "B.Tech in CSE (Cyber Security)" },
    { label: "Training", value: "QSpiders (Java Full Stack Development)" },
    { label: "Core Stack", value: "Java, Spring Boot, React.js, Python, MySQL" },
    { label: "Security & Cloud", value: "Network Security, Secure Coding, AWS, Azure" },
    { label: "Internship", value: "Octanet Services Pvt Ltd (Web Dev Intern)" },
    { label: "Certifications", value: "ISRO, NPTEL, Cisco (CCNA, Security, Python)" }
  ];

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>About Me</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Driven by Curiosity, Grounded in <span className="gradient-text">Core CS Fundamentals</span>
          </h2>
          <p className="mt-4 text-base text-slate-600 dark:text-slate-400">
            A look into my engineering background, technical passions, and motivation to build real-world software.
          </p>
        </div>

        {/* Top Grid: Bio Narrative & Profile Highlights */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          
          {/* Main Bio Card (7 cols) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-7 rounded-2xl p-6 sm:p-8 bg-white/70 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200 dark:border-white/10 shadow-xl shadow-slate-200/50 dark:shadow-none"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-brand-500/30">
                <Target className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  My Engineering Journey
                </h3>
                <p className="text-xs text-brand-600 dark:text-brand-400 font-medium">
                  Computer Science Student &amp; Aspiring Software Engineer
                </p>
              </div>
            </div>

            <div className="space-y-4 text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                Hello! I am <strong className="text-slate-900 dark:text-white font-semibold">Md Shaique Alam</strong>, a Computer Science undergraduate specializing in <strong className="text-brand-600 dark:text-brand-400 font-semibold">Cyber Security</strong>, skilled in Java, Python, JavaScript, React.js, Spring Boot, and MySQL.
              </p>
              <p>
                I maintain a strong foundation in Data Structures and Algorithms (DSA), Object-Oriented Programming (OOP), REST APIs, network security, and secure coding practices.
              </p>
              <p>
                Familiar with Git, modern SDLC practices, AWS, and Azure, my primary focus centers on architecting secure, reliable, and scalable web applications from backend services to responsive frontends.
              </p>
              <p className="text-slate-700 dark:text-slate-200 font-medium">
                My objective is to contribute to forward-thinking engineering teams as an intern or entry-level software engineer, building high-impact software while upholding strict security standards.
              </p>
            </div>

            {/* Core Interests Tag Pills */}
            <div className="mt-8 pt-6 border-t border-slate-200 dark:border-white/10">
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-500 dark:text-slate-400 block mb-3">
                Key Areas of Focus:
              </span>
              <div className="flex flex-wrap gap-2">
                {personalInfo.interests.map((interest) => (
                  <span
                    key={interest}
                    className="px-3 py-1 rounded-lg text-xs font-medium bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/10"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Quick Info & Academic Highlights (5 cols) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="lg:col-span-5 space-y-6"
          >
            {/* Quick Details Card */}
            <div className="rounded-2xl p-6 sm:p-7 bg-white/70 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200 dark:border-white/10 shadow-xl shadow-slate-200/50 dark:shadow-none">
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-brand-500" />
                <span>Profile Snapshot</span>
              </h3>
              
              <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs sm:text-sm">
                {quickDetails.map((item) => (
                  <div key={item.label} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">
                      {item.label}
                    </span>
                    <span className="text-slate-900 dark:text-white font-semibold sm:text-right">
                      {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Philosophy / Mindset Box */}
            <div className="rounded-2xl p-6 bg-gradient-to-br from-brand-900/20 via-indigo-900/10 to-transparent border border-brand-500/20 backdrop-blur-md">
              <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-sm mb-2">
                <Lightbulb className="w-4 h-4" />
                <span>Engineering Philosophy</span>
              </div>
              <blockquote className="text-xs sm:text-sm italic text-slate-600 dark:text-slate-300 leading-relaxed">
                "Writing software is an exercise in clarity. Clear object contracts, clean data boundaries, and deliberate problem decomposition always triumph over premature complexity."
              </blockquote>
            </div>

          </motion.div>
        </div>

        {/* Bottom: 4 Key Engineering Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {coreStrengths.map((strength, index) => {
            const Icon = strength.icon;
            return (
              <motion.div
                key={strength.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="group rounded-2xl p-5 sm:p-6 bg-white/60 dark:bg-[#0f1017]/70 border border-slate-200 dark:border-white/10 hover:border-brand-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg dark:hover:shadow-brand-950/40"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${strength.color} flex items-center justify-center text-white mb-4 shadow-sm group-hover:scale-105 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-900 dark:text-white text-base mb-2 group-hover:text-brand-500 transition-colors">
                  {strength.title}
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {strength.description}
                </p>
              </motion.div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
