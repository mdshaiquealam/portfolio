import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Code2, 
  ExternalLink, 
  Sparkles, 
  Layers, 
  Info, 
  X, 
  CheckCircle2, 
  FolderGit2, 
  Terminal,
  ArrowUpRight
} from 'lucide-react';
import { GithubIcon } from './Icons';
import { projectsData } from '../data/portfolioData';

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [activeFilter, setActiveFilter] = useState('All');

  const categories = ['All', ...Array.from(new Set(projectsData.map((project) => project.category)))];

  const filteredProjects = projectsData.filter((project) => {
    if (activeFilter === 'All') return true;
    return project.category === activeFilter;
  });

  return (
    <section id="projects" className="py-24 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-1/3 right-10 w-[450px] h-[350px] bg-brand-600/10 blur-[130px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-[400px] h-[300px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>Featured Work</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Academic &amp; Practical <span className="gradient-text">Software Projects</span>
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
            Showcasing foundational Java implementations, OOP architectural designs, relational database integration, and modern frontend development.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                activeFilter === cat
                  ? 'bg-gradient-to-r from-brand-600 to-indigo-600 text-white shadow-md shadow-brand-500/30'
                  : 'bg-white/70 dark:bg-[#0f1017]/80 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-white/10 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Projects Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              className="group relative rounded-2xl bg-white/70 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 hover:border-brand-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl dark:hover:shadow-brand-950/40 flex flex-col justify-between overflow-hidden"
            >
              {/* Card Header & Badges */}
              <div className="p-6 sm:p-7">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-brand-500/10 text-brand-600 dark:text-brand-400 border border-brand-500/30">
                      {project.badge}
                    </span>
                    {project.isExample && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-medium bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30">
                        Example Project
                      </span>
                    )}
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {project.category}
                  </span>
                </div>

                {/* Project Title */}
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-brand-500 transition-colors flex items-center justify-between">
                  <span>{project.title}</span>
                  <ArrowUpRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity text-brand-400" />
                </h3>

                {/* Description */}
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-5">
                  {project.description}
                </p>

                {/* Key Features Bullet points */}
                <div className="mb-6 space-y-1.5">
                  {project.features.slice(0, 3).map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-brand-400 mt-0.5 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>

                {/* Technology Badges */}
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md text-[11px] font-mono bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/10"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Actions Bar */}
              <div className="p-4 sm:px-7 bg-slate-50/80 dark:bg-[#0c0d14]/80 border-t border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-3">
                
                {/* Details Modal Trigger */}
                <button
                  onClick={() => setSelectedProject(project)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-500 transition-colors"
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Architecture &amp; Details</span>
                </button>

                {/* Links */}
                <div className="flex items-center gap-2">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-200/80 dark:bg-white/5 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-white/10 transition-colors"
                    title="View GitHub Repository"
                  >
                    <GithubIcon className="w-3.5 h-3.5" />
                    <span>Source</span>
                  </a>

                  {project.liveDemo ? (
                    <a
                      href={project.liveDemo}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-brand-600 hover:bg-brand-500 text-white transition-colors"
                      title="Live Project Link"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Live Preview</span>
                    </a>
                  ) : (
                    <span
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-white/5 text-slate-400 cursor-not-allowed border border-slate-200 dark:border-white/5"
                      title="Desktop / Console Application (No public web host)"
                    >
                      <Terminal className="w-3.5 h-3.5" />
                      <span>Console / Backend</span>
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Note on Example Projects */}
        <div className="mt-12 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 max-w-2xl mx-auto text-center">
          <p className="text-xs text-amber-700 dark:text-amber-300">
            <strong>Configuration Notice:</strong> These projects are sample implementations reflecting your coursework in Java &amp; Web development. To link your specific GitHub repositories or live URLs, simply update <code className="bg-amber-500/20 px-1.5 py-0.5 rounded text-[11px]">src/data/portfolioData.js</code>.
          </p>
        </div>

      </div>

      {/* Project Details Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.2 }}
              className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white dark:bg-[#0f1017] border border-slate-200 dark:border-white/15 p-6 sm:p-8 shadow-2xl text-slate-800 dark:text-slate-200"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-5 right-5 p-2 rounded-xl bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300 hover:text-black dark:hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 mb-2">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-brand-500/10 text-brand-600 dark:text-brand-400 border border-brand-500/30">
                  {selectedProject.badge}
                </span>
                <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                  {selectedProject.category}
                </span>
              </div>

              <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                {selectedProject.title}
              </h3>

              <div className="space-y-4 text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                <div>
                  <h4 className="font-semibold text-slate-900 dark:text-white text-xs uppercase tracking-wider mb-1">
                    Architectural Overview
                  </h4>
                  <p>{selectedProject.detailedOverview}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 dark:text-white text-xs uppercase tracking-wider mb-2">
                    Key Implemented Features
                  </h4>
                  <ul className="space-y-1.5">
                    {selectedProject.features.map((feat, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-slate-900 dark:text-white text-xs uppercase tracking-wider mb-2">
                    Tech Stack &amp; Libraries
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject.technologies.map((t) => (
                      <span key={t} className="px-2.5 py-1 rounded-md text-xs font-mono bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-white/10 flex items-center justify-between">
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                  {selectedProject.demoNote}
                </p>
                <a
                  href={selectedProject.github}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-brand-600 hover:bg-brand-500 text-white transition-colors"
                >
                  <GithubIcon className="w-4 h-4" />
                  <span>Visit Repository</span>
                </a>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
