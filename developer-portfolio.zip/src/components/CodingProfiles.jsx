import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ExternalLink, 
  Copy, 
  Check, 
  Code2, 
  Terminal, 
  Sparkles, 
  Award,
  Link2
} from 'lucide-react';
import { GithubIcon, LinkedinIcon, LeetCodeIcon, GFGIcon } from './Icons';
import { codingProfiles } from '../data/portfolioData';

export default function CodingProfiles() {
  const [copiedIndex, setCopiedIndex] = useState(null);

  const handleCopy = (url, index) => {
    navigator.clipboard.writeText(url);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getProfileIcon = (name) => {
    switch (name) {
      case 'GitHub':
        return GithubIcon;
      case 'LinkedIn':
        return LinkedinIcon;
      case 'LeetCode':
        return LeetCodeIcon;
      case 'GeeksforGeeks':
        return GFGIcon;
      case 'HackerRank':
        return Award;
      default:
        return Code2;
    }
  };

  return (
    <section id="profiles" className="py-24 relative overflow-hidden bg-slate-50/50 dark:bg-black/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Link2 className="w-3.5 h-3.5" />
            <span>Developer Presence</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Coding Profiles &amp; <span className="gradient-text">Networks</span>
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
            Connect across professional platforms, review active repositories, and track problem-solving journeys.
          </p>
        </div>

        {/* Profiles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {codingProfiles.map((profile, idx) => {
            const Icon = getProfileIcon(profile.name);
            const isCopied = copiedIndex === idx;

            return (
              <motion.div
                key={profile.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
                className="group relative rounded-2xl p-6 bg-white/70 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 hover:border-brand-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:hover:shadow-brand-950/40 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-white transition-transform group-hover:scale-105 shadow-md"
                      style={{ backgroundColor: profile.color }}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
                      {profile.category}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-1 group-hover:text-brand-500 transition-colors">
                    {profile.name}
                  </h3>
                  <p className="text-xs font-mono text-brand-600 dark:text-brand-400 mb-3">
                    {profile.handle}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                    {profile.description}
                  </p>
                </div>

                {/* Card Actions */}
                <div className="pt-4 border-t border-slate-200 dark:border-white/10 flex items-center gap-2">
                  <a
                    href={profile.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-white/5 text-slate-800 dark:text-slate-200 hover:bg-brand-600 hover:text-white dark:hover:bg-brand-600 transition-all"
                  >
                    <span>Visit Profile</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <button
                    onClick={() => handleCopy(profile.url, idx)}
                    title="Copy Profile URL"
                    className="p-2 rounded-xl bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:text-brand-500 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
                  >
                    {isCopied ? (
                      <Check className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Note on Customizing Coding Profiles */}
        <div className="mt-12 text-center text-xs text-slate-500 dark:text-slate-400 font-mono">
          Update your LeetCode, GeeksforGeeks, and HackerRank handles in <code className="bg-slate-100 dark:bg-white/10 px-1 py-0.5 rounded">portfolioData.js</code> anytime.
        </div>

      </div>
    </section>
  );
}
