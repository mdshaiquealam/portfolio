import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Code, 
  Terminal, 
  Database, 
  Layers, 
  Wrench, 
  Cpu, 
  Search, 
  Sparkles, 
  CheckCircle,
  BookOpen
} from 'lucide-react';
import { skillsData } from '../data/portfolioData';

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSkills = skillsData.skills.filter((skill) => {
    const matchesCategory = activeCategory === 'all' || skill.category === activeCategory;
    const matchesSearch = skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          skill.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getCategoryIcon = (categoryId) => {
    switch (categoryId) {
      case 'programming':
        return Code;
      case 'frontend':
        return Layers;
      case 'database':
        return Database;
      case 'core':
        return Cpu;
      case 'tools':
        return Wrench;
      default:
        return Sparkles;
    }
  };

  const getLevelBadgeClass = (level) => {
    switch (level) {
      case 'Advanced':
        return 'bg-purple-500/15 text-purple-600 dark:text-purple-300 border-purple-500/30';
      case 'Proficient':
        return 'bg-blue-500/15 text-blue-600 dark:text-blue-300 border-blue-500/30';
      default:
        return 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 border-emerald-500/30';
    }
  };

  return (
    <section id="skills" className="py-24 relative overflow-hidden bg-slate-50/50 dark:bg-black/20">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-brand-600/10 blur-[140px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Layers className="w-3.5 h-3.5" />
            <span>Technical Expertise</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Skills &amp; <span className="gradient-text">Core Competencies</span>
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
            A comprehensive overview of programming languages, frontend tools, databases, and foundational CS principles honed through coursework and project building.
          </p>
        </div>

        {/* Filter Tabs and Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-10">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 rounded-2xl bg-white/70 dark:bg-[#0f1017]/80 border border-slate-200 dark:border-white/10 backdrop-blur-md">
            {skillsData.categories.map((category) => {
              const Icon = getCategoryIcon(category.id);
              const isActive = activeCategory === category.id;
              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-gradient-to-r from-brand-600 to-indigo-600 text-white shadow-md shadow-brand-500/30 scale-[1.02]'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{category.name}</span>
                </button>
              );
            })}
          </div>

          {/* Quick Search */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-white/70 dark:bg-[#0f1017]/80 border border-slate-200 dark:border-white/10 text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-brand-500 transition-colors"
            />
          </div>
        </div>

        {/* Skills Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          <AnimatePresence>
            {filteredSkills.map((skill) => {
              const CategoryIcon = getCategoryIcon(skill.category);
              return (
                <motion.div
                  layout
                  key={skill.name}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.25 }}
                  className="group relative rounded-2xl p-5 bg-white/80 dark:bg-[#0f1017]/70 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 hover:border-brand-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:hover:shadow-brand-950/30 flex flex-col justify-between"
                >
                  <div>
                    {/* Top Row: Icon, Title, and Level Badge */}
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 flex items-center justify-center text-brand-600 dark:text-brand-400 group-hover:bg-brand-500 group-hover:text-white transition-all duration-300">
                          <CategoryIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-slate-900 dark:text-white text-base group-hover:text-brand-500 transition-colors">
                            {skill.name}
                          </h3>
                          <span className="text-[11px] text-slate-400 capitalize">
                            {skill.category}
                          </span>
                        </div>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${getLevelBadgeClass(skill.level)}`}>
                        {skill.level}
                      </span>
                    </div>

                    {/* Skill description */}
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                      {skill.description}
                    </p>
                  </div>

                  {/* Animated Proficiency Bar */}
                  <div className="pt-2 border-t border-slate-100 dark:border-white/5">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 dark:text-slate-400 mb-1.5 font-mono">
                      <span>Proficiency</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{skill.proficiency}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.proficiency}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-brand-500 to-indigo-500 rounded-full"
                      />
                    </div>
                  </div>

                  {/* Highlight Glow Accent */}
                  {skill.highlight && (
                    <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-brand-400" title="Core Focus" />
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

        {filteredSkills.length === 0 && (
          <div className="text-center py-12 text-slate-400 text-sm">
            No skills found matching your search. Try adjusting the query or category filter.
          </div>
        )}

        {/* Verification Note */}
        <div className="mt-12 text-center">
          <p className="inline-flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-mono">
            <CheckCircle className="w-3.5 h-3.5 text-brand-400" />
            <span>Honest skill metrics based on coursework, hands-on lab practice, and project code.</span>
          </p>
        </div>

      </div>
    </section>
  );
}
