import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Briefcase, 
  Award, 
  Calendar, 
  MapPin, 
  ExternalLink, 
  CheckCircle2, 
  Sparkles,
  FileCheck,
  Building,
  ShieldCheck,
  Check
} from 'lucide-react';
import { experienceData } from '../data/portfolioData';

export default function ExperienceCertifications() {
  const [activeTab, setActiveTab] = useState('experience');

  return (
    <section id="experience" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Work &amp; Credentials</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Work Experience, Training &amp; <span className="gradient-text">Certifications</span>
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-400">
            Real industry internship at Octanet Services, professional Java Full Stack training at QSpiders, and accredited certifications from ISRO, NPTEL, and Cisco.
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="p-1 rounded-2xl bg-white/70 dark:bg-[#0f1017]/80 border border-slate-200 dark:border-white/10 backdrop-blur-md flex items-center">
            <button
              onClick={() => setActiveTab('experience')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                activeTab === 'experience'
                  ? 'bg-gradient-to-r from-brand-600 to-indigo-600 text-white shadow-md shadow-brand-500/30'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>Work Experience ({experienceData.internships.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('certifications')}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                activeTab === 'certifications'
                  ? 'bg-gradient-to-r from-brand-600 to-indigo-600 text-white shadow-md shadow-brand-500/30'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>Certifications &amp; Training ({experienceData.certifications.length})</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Internships & Work Experience */}
        {activeTab === 'experience' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {experienceData.internships.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.1 }}
                className="rounded-2xl p-6 sm:p-8 bg-white/80 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 hover:border-brand-500/40 transition-all duration-300 shadow-xl shadow-slate-200/40 dark:shadow-none relative overflow-hidden"
              >
                {/* Header row */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-brand-500/15 text-brand-600 dark:text-brand-400 border border-brand-500/30">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>{item.badge}</span>
                    </span>
                    <span className="text-xs font-mono text-emerald-600 dark:text-emerald-400 font-medium">
                      Verified
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500 dark:text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-brand-500" />
                    <span>{item.duration}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                      {item.role}
                    </h3>
                    <p className="text-sm font-semibold text-brand-600 dark:text-brand-400 flex items-center gap-1.5 mt-1">
                      <Building className="w-4 h-4 text-brand-500" />
                      <span>{item.company}</span>
                      <span className="text-slate-400 font-normal">&bull; {item.location}</span>
                    </p>
                  </div>
                </div>

                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-5">
                  {item.description}
                </p>

                {/* Key Achievements Bullet points */}
                <div className="space-y-2 mb-6">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-2">
                    Key Contributions &amp; Impact:
                  </span>
                  {item.highlights.map((hl, hIdx) => (
                    <div key={hIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="leading-relaxed">{hl}</span>
                    </div>
                  ))}
                </div>

                {/* Technologies */}
                {item.technologies && (
                  <div className="pt-4 border-t border-slate-100 dark:border-white/5 flex flex-wrap items-center gap-2">
                    <span className="text-xs font-medium text-slate-400">Technologies:</span>
                    {item.technologies.map((t) => (
                      <span 
                        key={t}
                        className="px-2.5 py-0.5 rounded-md text-xs font-mono bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-white/10"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}

            {/* Opportunities Banner */}
            <div className="rounded-2xl p-6 bg-gradient-to-r from-emerald-500/10 via-brand-500/10 to-transparent border border-emerald-500/30 text-center">
              <div className="flex items-center justify-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-base mb-1">
                <Sparkles className="w-5 h-5" />
                <span>Available for Software Engineering Opportunities</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto">
                Equipped with real frontend engineering and API integration experience at Octanet Services Pvt Ltd.
              </p>
            </div>
          </div>
        )}

        {/* Tab 2: Certifications */}
        {activeTab === 'certifications' && (
          <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {experienceData.certifications.map((cert, cIdx) => (
              <motion.div
                key={cIdx}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: cIdx * 0.08 }}
                className="group rounded-2xl p-6 bg-white/80 dark:bg-[#0f1017]/80 backdrop-blur-xl border border-slate-200/90 dark:border-white/10 hover:border-brand-500/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:hover:shadow-brand-950/40 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-brand-600/20 to-indigo-600/20 border border-brand-500/30 flex items-center justify-center text-brand-600 dark:text-brand-400 group-hover:scale-105 transition-transform">
                      <FileCheck className="w-6 h-6" />
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-brand-500/15 text-brand-600 dark:text-brand-300 border border-brand-500/30">
                      {cert.badge}
                    </span>
                  </div>

                  <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
                    {cert.category}
                  </span>

                  <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-brand-500 transition-colors">
                    {cert.title}
                  </h3>

                  <p className="text-xs font-semibold text-brand-600 dark:text-brand-400 mb-3">
                    {cert.issuer}
                  </p>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                    {cert.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-white/5 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                    <Check className="w-3.5 h-3.5" />
                    <span>{cert.date}</span>
                  </span>
                  <span className="text-[10px] text-slate-400">ID: {cert.credentialId}</span>
                </div>
              </motion.div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
}
